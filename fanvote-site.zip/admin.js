const client = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

let adminPassword = null;
let polls = [];

const loginScreen = document.getElementById("loginScreen");
const adminScreen = document.getElementById("adminScreen");
const passwordInput = document.getElementById("passwordInput");
const loginBtn = document.getElementById("loginBtn");
const loginError = document.getElementById("loginError");
const pollList = document.getElementById("pollList");

loginBtn.addEventListener("click", login);
passwordInput.addEventListener("keydown", e => { if (e.key === "Enter") login(); });

async function login() {
  const pw = passwordInput.value.trim();
  if (!pw) return;
  loginError.textContent = "";
  loginBtn.textContent = "Checking…";

  // Verify the password by attempting a harmless admin call (reset_votes on a non-existent id).
  const { error } = await client.rpc("admin_reset_votes", { admin_password: pw, p_id: -1 });

  loginBtn.textContent = "Log in";
  if (error && error.message && error.message.includes("Invalid password")) {
    loginError.textContent = "Wrong password.";
    return;
  }
  adminPassword = pw;
  sessionStorage.setItem("fanvote_admin_pw", pw);
  loginScreen.classList.add("hidden");
  adminScreen.classList.remove("hidden");
  loadPolls();
}

// Auto-login if already verified this session
const savedPw = sessionStorage.getItem("fanvote_admin_pw");
if (savedPw) {
  adminPassword = savedPw;
  loginScreen.classList.add("hidden");
  adminScreen.classList.remove("hidden");
  loadPolls();
}

async function loadPolls() {
  pollList.innerHTML = `<div class="loading">Loading…</div>`;
  const { data, error } = await client
    .from("polls")
    .select("*")
    .order("type", { ascending: true })
    .order("sort_order", { ascending: true });

  if (error) {
    pollList.innerHTML = `<div class="loading">Couldn't load polls.</div>`;
    return;
  }
  polls = data || [];
  renderList();
}

function renderList() {
  if (polls.length === 0) {
    pollList.innerHTML = `<div class="loading">No polls yet.</div>`;
    return;
  }
  pollList.innerHTML = polls.map(p => {
    const total = (p.votes_a || 0) + (p.votes_b || 0);
    return `
    <div class="poll-row" data-id="${p.id}">
      <div class="poll-row-top">
        <div>
          <div class="poll-row-title">${escapeHtml(p.name_a)} vs ${escapeHtml(p.name_b)}</div>
          <div class="poll-row-sub">${p.type} &middot; ${total} vote${total === 1 ? "" : "s"}</div>
        </div>
        <div class="pill ${p.active ? "" : "inactive"}">${p.active ? "ACTIVE" : "HIDDEN"}</div>
      </div>
      <div class="row-actions">
        <button class="editBtn">Edit</button>
        <button class="resetBtn">Reset votes</button>
        <button class="danger deleteBtn">Delete</button>
      </div>
    </div>`;
  }).join("");

  pollList.querySelectorAll(".poll-row").forEach(row => {
    const id = Number(row.dataset.id);
    const poll = polls.find(p => p.id === id);
    row.querySelector(".editBtn").addEventListener("click", () => openEdit(poll));
    row.querySelector(".resetBtn").addEventListener("click", () => resetVotes(poll));
    row.querySelector(".deleteBtn").addEventListener("click", () => deletePoll(poll));
  });
}

// --- Add poll ---
document.getElementById("addBtn").addEventListener("click", async () => {
  const addMsg = document.getElementById("addMsg");
  const payload = {
    admin_password: adminPassword,
    p_id: null,
    p_type: document.getElementById("f_type").value,
    p_title: document.getElementById("f_title").value || "WHO'S BETTER?",
    p_name_a: document.getElementById("f_name_a").value.trim(),
    p_image_a: document.getElementById("f_image_a").value.trim(),
    p_badge_a: document.getElementById("f_badge_a").value.trim() || null,
    p_name_b: document.getElementById("f_name_b").value.trim(),
    p_image_b: document.getElementById("f_image_b").value.trim(),
    p_badge_b: document.getElementById("f_badge_b").value.trim() || null,
    p_active: true,
    p_sort_order: 0
  };

  if (!payload.p_name_a || !payload.p_name_b || !payload.p_image_a || !payload.p_image_b) {
    addMsg.textContent = "Fill in both names and both image URLs.";
    addMsg.className = "msg err";
    return;
  }

  const { error } = await client.rpc("admin_upsert_poll", payload);
  if (error) {
    addMsg.textContent = "Error: " + error.message;
    addMsg.className = "msg err";
    return;
  }
  addMsg.textContent = "Poll added!";
  addMsg.className = "msg ok";
  ["f_title", "f_name_a", "f_name_b", "f_image_a", "f_image_b", "f_badge_a", "f_badge_b"].forEach(id => {
    document.getElementById(id).value = "";
  });
  loadPolls();
});

// --- Edit poll ---
const editOverlay = document.getElementById("editOverlay");

function openEdit(poll) {
  document.getElementById("e_id").value = poll.id;
  document.getElementById("e_type").value = poll.type;
  document.getElementById("e_title").value = poll.title || "";
  document.getElementById("e_name_a").value = poll.name_a || "";
  document.getElementById("e_name_b").value = poll.name_b || "";
  document.getElementById("e_image_a").value = poll.image_a || "";
  document.getElementById("e_image_b").value = poll.image_b || "";
  document.getElementById("e_badge_a").value = poll.badge_a || "";
  document.getElementById("e_badge_b").value = poll.badge_b || "";
  document.getElementById("e_active").value = String(poll.active);
  document.getElementById("editMsg").textContent = "";
  editOverlay.classList.remove("hidden");
}

document.getElementById("cancelEditBtn").addEventListener("click", () => {
  editOverlay.classList.add("hidden");
});

document.getElementById("saveEditBtn").addEventListener("click", async () => {
  const editMsg = document.getElementById("editMsg");
  const payload = {
    admin_password: adminPassword,
    p_id: Number(document.getElementById("e_id").value),
    p_type: document.getElementById("e_type").value,
    p_title: document.getElementById("e_title").value || "WHO'S BETTER?",
    p_name_a: document.getElementById("e_name_a").value.trim(),
    p_image_a: document.getElementById("e_image_a").value.trim(),
    p_badge_a: document.getElementById("e_badge_a").value.trim() || null,
    p_name_b: document.getElementById("e_name_b").value.trim(),
    p_image_b: document.getElementById("e_image_b").value.trim(),
    p_badge_b: document.getElementById("e_badge_b").value.trim() || null,
    p_active: document.getElementById("e_active").value === "true",
    p_sort_order: 0
  };

  const { error } = await client.rpc("admin_upsert_poll", payload);
  if (error) {
    editMsg.textContent = "Error: " + error.message;
    editMsg.className = "msg err";
    return;
  }
  editOverlay.classList.add("hidden");
  loadPolls();
});

// --- Reset votes ---
async function resetVotes(poll) {
  if (!confirm(`Reset votes for ${poll.name_a} vs ${poll.name_b}?`)) return;
  const { error } = await client.rpc("admin_reset_votes", { admin_password: adminPassword, p_id: poll.id });
  if (!error) loadPolls();
}

// --- Delete poll ---
async function deletePoll(poll) {
  if (!confirm(`Delete ${poll.name_a} vs ${poll.name_b}? This can't be undone.`)) return;
  const { error } = await client.rpc("admin_delete_poll", { admin_password: adminPassword, p_id: poll.id });
  if (!error) loadPolls();
}

function escapeHtml(str) {
  if (!str) return "";
  return str.replace(/[&<>"']/g, m => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[m]));
}
