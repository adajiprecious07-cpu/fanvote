-- Run this once in Supabase: SQL Editor > New query > paste all > Run

create table if not exists polls (
  id bigint generated always as identity primary key,
  type text not null check (type in ('player', 'team')),
  title text not null default 'WHO''S BETTER?',
  name_a text not null,
  image_a text not null,
  badge_a text,
  votes_a integer not null default 0,
  name_b text not null,
  image_b text not null,
  badge_b text,
  votes_b integer not null default 0,
  active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

alter table polls enable row level security;

create policy "Public can read active polls"
  on polls for select
  using (true);

-- Lets the site increment a vote count safely (no direct write access needed)
create or replace function increment_vote(poll_id bigint, vote_column text)
returns void
language plpgsql
security definer
as $$
begin
  if vote_column = 'votes_a' then
    update polls set votes_a = votes_a + 1 where id = poll_id;
  elsif vote_column = 'votes_b' then
    update polls set votes_b = votes_b + 1 where id = poll_id;
  end if;
end;
$$;

-- A couple of starter polls so the site isn't empty on first load.
-- Swap in real photo URLs afterward (see note below).
insert into polls (type, title, name_a, image_a, name_b, image_b, sort_order)
values
  ('player', 'WHO''S BETTER?', 'Rodrygo', 'https://placehold.co/200x200?text=Rodrygo', 'Lamine Yamal', 'https://placehold.co/200x200?text=Yamal', 1),
  ('team', 'WHO''S BETTER?', 'Real Madrid', 'https://placehold.co/200x200?text=RMA', 'Barcelona', 'https://placehold.co/200x200?text=FCB', 1);
