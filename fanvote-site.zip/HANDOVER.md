# FanVote — Handover Note

**Last updated:** 2026-10-28

## What this is
A football fan voting site — "Who's better?" head-to-head polls, player vs player and team vs team, with live percentage bars. Separate project from Touchline NG.

## Live site
- Hosted on **Cloudflare Pages**, account adajipresh41@gmail.com
- Project name: `toy-boat-3e09` (Cloudflare auto-generated this name on first deploy)
- URL: `https://toy-boat-3e09.adajipresh41....pages.dev` (check exact URL in Cloudflare dashboard > Workers & Pages)

## Backend
- **Supabase** project: "Fanvote" (org: adajiprecious07's Org)
- Project URL: `https://mwttunspdyzlwebkgmlb.supabase.co`
- Publishable (anon) key is in `config.js` — safe to expose in the browser
- Database: one table, `polls` (see `supabase-setup.sql` for schema)
- Votes are incremented via the `increment_vote` Postgres function (called through Supabase RPC) — the site never writes to the table directly
- One vote per poll per device, enforced client-side via localStorage (not foolproof, but enough for a casual fan site)

## Files
- `index.html` — page structure and styling
- `app.js` — loads polls from Supabase, renders cards, handles voting
- `config.js` — Supabase URL + publishable key
- `supabase-setup.sql` — run once in Supabase SQL Editor to create the table/function and two starter polls

## How to update or add polls
No admin dashboard yet — add/edit polls directly in Supabase:
1. Supabase dashboard > Table Editor > `polls`
2. Insert a new row (type: `player` or `team`, name_a/image_a, name_b/image_b, etc.) or edit an existing one
3. Changes show up immediately on the site — no redeploy needed

## How to redeploy the site (after editing index.html/app.js/config.js)
1. Cloudflare dashboard > Workers & Pages > the FanVote project
2. Deployments tab > upload the new files (same "upload assets" flow as the first deploy)

## Known placeholders / next steps
- Starter poll images use placehold.co (grey boxes with text) — replace `image_a` / `image_b` in Supabase with real photo URLs
- No admin dashboard — all poll management is manual via Supabase Table Editor
- No way to delete/retract a vote once cast (by design, keeps it simple)
- Consider: a simple password-protected admin page for adding polls without touching Supabase directly, team/player badge icons, a "trending" or "most voted" view
