const client = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

let currentType = "player";
let polls = [];

const container = document.getElementById("pollContainer");
const tabs = document.querySelectorAll(".tab");

tabs.forEach(tab => {
  tab.addEventListener("click", () => {
    tabs.forEach(t => t.classList.remove("active"));
    tab.classList.add("active");
    currentType = tab.dataset.type;
    render();
  });
});

function votedKey(pollId) {
  return `fanvote_voted_${pollId}`;
}

function hasVoted(pollId) {
  return localStorage.getItem(votedKey(pollId)) !== null;
}

function getVotedSide(pollId) {
  return localStorage.getItem(votedKey(pollId));
}

function markVoted(pollId, side) {
  localStorage.setItem(votedKey(pollId), side);
}

async function loadPolls() {
  const { data, error } = await client
    .from("polls")
    .select("*")
    .eq("active", true)
    .order("sort_order", { ascending: true });

  if (error) {
    container.innerHTML = `<div class="empty">Couldn't load polls. Check your connection and try again.</div>`;
    console.error(error);
    return;
  }
  polls = data || [];
  render();
}

function render() {
  const filtered = polls.filter(p => p.type === currentType);
  if (filtered.length === 0) {
    container.innerHTML = `<div class="empty">No ${currentType} polls yet. Check back soon.</div>`;
    return;
  }
  container.innerHTML = filtered.map(renderPoll).join("");
  filtered.forEach(attachHandlers);
}

function renderPoll(poll) {
  const total = (poll.votes_a || 0) + (poll.votes_b || 0);
  const pctA = total > 0 ? Math.round((poll.votes_a / total) * 100) : 0;
  const pctB = total > 0 ? Math.round((poll.votes_b / total) * 100) : 0;
  const voted = hasVoted(poll.id);
  const votedSide = getVotedSide(poll.id);

  return `
    <div class="poll-card" data-id="${poll.id}">
      <div class="poll-title">${escapeHtml(poll.title || "WHO'S BETTER?")}</div>
      <div class="matchup">
        <button class="side left" data-side="a" ${voted ? "disabled" : ""}>
          ${poll.badge_a ? `<img class="badge" src="${poll.badge_a}" alt="">` : ""}
          <img src="${poll.image_a}" alt="${escapeHtml(poll.name_a)}">
          <div class="name">${escapeHtml(poll.name_a)}</div>
        </button>
        <button class="side right" data-side="b" ${voted ? "disabled" : ""}>
          ${poll.badge_b ? `<img class="badge" src="${poll.badge_b}" alt="">` : ""}
          <img src="${poll.image_b}" alt="${escapeHtml(poll.name_b)}">
          <div class="name">${escapeHtml(poll.name_b)}</div>
        </button>
      </div>
      <div class="results">
        <div class="bar-row">
          <div class="bar-label">${escapeHtml(poll.name_a)}</div>
          <div class="bar-track"><div class="bar-fill ${pctA >= pctB ? "win" : ""}" style="width:${pctA}%"></div></div>
          <div class="bar-pct">${pctA}%</div>
        </div>
        <div class="bar-row">
          <div class="bar-label">${escapeHtml(poll.name_b)}</div>
          <div class="bar-track"><div class="bar-fill ${pctB > pctA ? "win" : ""}" style="width:${pctB}%"></div></div>
          <div class="bar-pct">${pctB}%</div>
        </div>
        <div class="vote-count">${total.toLocaleString()} vote${total === 1 ? "" : "s"}</div>
        ${voted ? `<div class="voted-note">You voted ${votedSide === "a" ? escapeHtml(poll.name_a) : escapeHtml(poll.name_b)}</div>` : ""}
      </div>
    </div>
  `;
}

function attachHandlers(poll) {
  const card = container.querySelector(`.poll-card[data-id="${poll.id}"]`);
  if (!card) return;
  card.querySelectorAll(".side").forEach(btn => {
    btn.addEventListener("click", () => castVote(poll, btn.dataset.side));
  });
}

async function castVote(poll, side) {
  if (hasVoted(poll.id)) return;
  markVoted(poll.id, side);

  const column = side === "a" ? "votes_a" : "votes_b";
  const { error } = await client.rpc("increment_vote", {
    poll_id: poll.id,
    vote_column: column
  });

  if (error) {
    console.error(error);
  }
  await loadPolls();
}

function escapeHtml(str) {
  if (!str) return "";
  return str.replace(/[&<>"']/g, m => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[m]));
}

loadPolls();
