-- Run this once in Supabase SQL Editor (after the first supabase-setup.sql)
-- Adds admin functions so the admin page can add/edit/delete polls.
-- Your admin password is baked in here as plain text comparisons below.

create or replace function admin_upsert_poll(
  admin_password text,
  p_id bigint,
  p_type text,
  p_title text,
  p_name_a text,
  p_image_a text,
  p_badge_a text,
  p_name_b text,
  p_image_b text,
  p_badge_b text,
  p_active boolean,
  p_sort_order integer
) returns bigint
language plpgsql
security definer
as $$
declare
  result_id bigint;
begin
  if admin_password <> 'Precious09016090318' then
    raise exception 'Invalid password';
  end if;

  if p_id is null then
    insert into polls (type, title, name_a, image_a, badge_a, name_b, image_b, badge_b, active, sort_order)
    values (p_type, p_title, p_name_a, p_image_a, p_badge_a, p_name_b, p_image_b, p_badge_b, p_active, p_sort_order)
    returning id into result_id;
  else
    update polls set
      type = p_type,
      title = p_title,
      name_a = p_name_a,
      image_a = p_image_a,
      badge_a = p_badge_a,
      name_b = p_name_b,
      image_b = p_image_b,
      badge_b = p_badge_b,
      active = p_active,
      sort_order = p_sort_order
    where id = p_id
    returning id into result_id;
  end if;

  return result_id;
end;
$$;

create or replace function admin_delete_poll(admin_password text, p_id bigint)
returns void
language plpgsql
security definer
as $$
begin
  if admin_password <> 'Precious09016090318' then
    raise exception 'Invalid password';
  end if;
  delete from polls where id = p_id;
end;
$$;

create or replace function admin_reset_votes(admin_password text, p_id bigint)
returns void
language plpgsql
security definer
as $$
begin
  if admin_password <> 'Precious09016090318' then
    raise exception 'Invalid password';
  end if;
  update polls set votes_a = 0, votes_b = 0 where id = p_id;
end;
$$;
