// Fill these in with your new Supabase project's values.
// Found in Supabase: Project Settings > API
const SUPABASE_URL = "https://mwttunspdyzlwebkgmlb.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_lDQICz3MAUcNKoVFcw9Xiw_Ui9RXbRu";
